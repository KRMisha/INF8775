#!/usr/bin/env sh

exec ./tp "$@"
